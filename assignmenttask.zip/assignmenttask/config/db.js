module.exports = {
  url : "mongodb://bflogadmin:safe4now@bfmongo201.innovate.ibm.com:27017/bfdata"
};
